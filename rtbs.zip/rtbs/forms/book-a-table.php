<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Create a MySQL database connection
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'dbanikesh';

$mysqli = new mysqli($host, $user, $password, $database);

// Check if the connection was successful
if ($mysqli->connect_error) {
  die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Get the form data
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $people = $_POST['people'];
  $message = $_POST['message'];

  // Prepare the SQL statement
  $stmt = $mysqli->prepare("INSERT INTO customer_info (name, email, phone, date, time, people, message) VALUES (?, ?, ?, ?, ?, ?, ?)");

  if ($stmt) {
    // Bind the parameters to the statement
    $stmt->bind_param("sssssss", $name, $email, $phone, $date, $time, $people, $message);

    // Execute the statement
    if ($stmt->execute()) {
      echo 'Form data inserted successfully';
    } else {
      echo 'Error inserting form data: ' . $stmt->error;
    }

    // Close the statement
    $stmt->close();
  } else {
    echo 'Error preparing statement: ' . $mysqli->error;
  }
} else {
  echo 'No form data submitted';
}

// Close the database connection
$mysqli->close();
?>
